function ValidateEmail(inputText)
{
var mailformat = '[A-Za-z0-9]{1,50}@gmail.com';
if(inputText.value.match(mailformat))
{
alert("Valid email address!");
document.form1.text1.focus();
return true;
}
else
{
alert("You have entered an invalid email address!");
document.form1.text1.focus();
return false;
}
}