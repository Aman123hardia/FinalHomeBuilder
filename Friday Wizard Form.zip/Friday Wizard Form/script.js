var step=1


let formValue=[['fname','lname','email','phone','adhar'],['currentAdd','permanentAdd','city1','state1','pincode1','country1'],['institute','address','city2','state2','pincode2','country2'],['course','branch','rollNu','percentage'],['bankName','branch','account','ifsc']]

let formkeys=[  ["^[A-Za-z][A-Za-z_]{4,29}$"  , "^[A-Za-z][A-Za-z_]{4,29}$",
                 "[A-Za-z0-9]{1,50}@gmail.com" , "^\\d{10}$",
                  "^\\d{12}$",
                 ],
                 
                 [
                  "^[A-Za-z][A-Za-z_0-9 ]{4,80}$",
                  "^[A-Z0-9][A-Za-z_0-9 ]{4,80}$",
                  "^[A-Za-z][A-Za-z_]{4,29}$",
                  "^\\d{12}$",
                  "^[A-Za-z][A-Za-z_]{4,29}$",
                  "^[A-Za-z][A-Za-z_]{4,29}$"
                 
                 
                 ],
                 
                 [
                  "^[A-Za-z][A-Za-z_]{4,29}$",
                  "^[A-Za-z][A-Za-z_]{4,29}$",
                  "^[A-Za-z][A-Za-z_]{4,29}$",
                  "^\\d{6}$",
                  "^[A-Za-z][A-Za-z_]{4,29}$",
                 
                 ],
                 
                 [
                  "^[A-Za-z][A-Za-z_]{4,29}$",
                  "^[A-Za-z][A-Za-z_]{4,29}$",
                  "^\\d{10}$",
                  "^100(\.0{1,2})?$",
                 
                 ],
                 
                 [
                  "^[A-Za-z][A-Za-z_]{4,29}$",
                  "^[A-Za-z][A-Za-z_]{4,29}$",
                  "^\\d{16}$",
                  "^\\d{10}$"
                 
                 ]
                 ]
                 
$(document).ready(function(){
  let steps=["<li id='step11' class='is-active'>Personal Information</li>", 
             "<li id='step22'>Address Information</li>"  ,
             "<li id='step33'>Institute Information</li>",
             "<li id='step44'>Applicant Details</li>",
             "<li id='step55'>Bank Information</li>"
           ] 
    
  let religion=["<option value='' selected='selected' disabled='disabled'>-- select one --</option>",
             "<option value='African Traditional &amp; Diasporic'>African Traditional &amp;Diasporic</option>",
             "<option value='Agnostic'>Agnostic</option>",
             "<option value='Atheist'>Atheist</option>",
             "<option value='Baha'i'>Baha'i</option>",
             "<option value='Buddhism'>Buddhism</option>",
             "<option value='Cao Dai'>Cao Dai</option>",
             "<option value='Chinese traditional religion'>Chinese traditional religion</option>",
             "<option value='Christianity'>Christianity</option>",
             "<option value='Hinduism'>Hinduism</option>",
             "<option value='Islam'>Islam</option>",
             "<option value='Jainism'>Jainism</option>",
             "<option value='Juche'>Juche</option>",
             "<option value='Judaism'>Judaism</option>",
             "<option value='Neo-Paganism'>Neo-Paganism</option>",
             "<option value='Nonreligious'>Nonreligious</option>",
             "<option value='Rastafarianism'>Rastafarianism</option>",
             "<option value='Secular'>Secular</option>",
             "<option value='Shinto'>Shinto</option>",
             "<option value='Sikhism'>Sikhism</option>",
             "<option value='Spiritism'>Spiritism</option>",
             "<option value='Tenrikyo'>Tenrikyo</option>",
             "<option value='Unitarian-Universalism'>Unitarian-Universalism</option>",
             "<option value='Zoroastrianism'>Zoroastrianism</option>",
             "<option value='primal-indigenous'>primal-indigenous</option>",
             "<option value='Other'>Other</option>"
            ]

  for(let i=0;i<steps.length;i++){
    $(".multi-steps").append(steps[i])
  }
  
  for(let i=0;i<religion.length;i++){
    $(".br").append(religion[i])
  }

})

function personalInfoPage(){
    step="#step"+step
    $(step).show()

    step=1
    $("#next"+step).attr('disabled',true)
}
personalInfoPage()


function nextButton(e){
  e.preventDefault();
    let temp=step
    if(step<=4){
    temp="#step"+temp
    $(temp).hide()
    $(temp+step).removeClass("is-active");
    temp=""
    step=step+1
    temp="#step"+(step)
    $(temp).show()
    console.log(temp+step)
    $(temp+step).addClass("is-active");
    $("#next"+step).attr('disabled',true)
}
}

function previousButton(e){
    e.preventDefault();
    let temp=step
    temp="#step"+temp
    $(temp+step).removeClass("is-active");
    $(temp).hide()
    temp="#step"
    step=step-1
    temp=temp+(step)
    $(temp+step).addClass("is-active");
    $(temp).show()
}




function validation(){

 for(let i=0;i<formValue[step-1].length;i++){
 
    let search=formValue[step-1][i];
    $("input[name='"+search+"']").css("background-color", "white")
    let x = document.forms["formData"][search].value;
 
    if (x == "") {
      $("input[name='"+search+"']").css("background-color", "#ffefd5")
      return false
    }
    else{
    let compare=new RegExp(formkeys[step-1][i])
     if(compare.test(x)){
 
     }
     else{
      $("input[name='"+search+"']").css("background-color", "#ffefd5")
      return false
     }
   
    }
  
  }

  $("#next"+step).attr('disabled',false)


}











// fetch('data.json')
//    .then(response => response.json())
//    .then(text =>jsonData(text)
//    )

// function jsonData(text){
//    for(let i=0;i<text.length;i++){
//       debugger
//       for(let j=0;j<Object.keys(text[i]).length;j++){
//          //   if(Object.keys(text[i])[j]=='name'){
//          //   console.log("Country"+ Object.values(text[i])[j])
//          //   }

//            if(Object.keys(text[i])[j]=='state'){
//             for(let k=0;k<Object.keys(text[i][j]).length;k++){
//            console.log("Country"+ Object.keys(text[i][j])[k])
//            }
   
// }
//    }}
// }
   


// let formkeys=[['^[A-Za-z][A-Za-z_]{7,29}$','^[A-Za-z][A-Za-z]{7,29}$','/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/.','/^(\+\d{1,3}[- ]?)?\d{10}$/','DOB','^[2-9]{1}[0-9]{3}\\s[0-9]{4}\\s[0-9]{4}$','A-Za-z][A-Za-z_'],['current Address','permanent Address','city','state','pincode','country'],['institute Name','address','city','state','pincode','country'],['course','branch','roll Number','percentage'],['bank Name','branch Address','Account Number','ifsc']]
// let formValue=[['fname','lname','email','phone','date','adhar','religion'],['currentAdd','permanentAdd','city1','state1','pincode1','country1'],['institute','address','city2','state2','pincode2','country2'],['course','branch','rollNu','percentage'],['bankName','branch','account','ifsc']]
// for(let i=0;i<formValue[step-1].length;i++){
// let search=formValue[step-1][i];
// $("input[name='"+search+"']").css("background-color", "white")
// let x = document.forms["formData"][search].value;
// console.log(x)
// if (x == "") {
//   $("input[name='"+search+"']").css("background-color", "#ffefd5")
//   return false
// }
// else{
// let compare=new RegExp(formkeys[step-1][i])
//  if(!compare.test(x)){
//   $("input[name='"+search+"']").css("background-color", "#ffefd5")
//    return false
//  }
//  else
//   return true
// }
// }