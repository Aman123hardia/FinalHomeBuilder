<?php
  $files = $_FILES['upload']['name'];
  $count = count($_FILES['upload']['name']);

  for( $i=0 ; $i < $count ; $i++ ) 
  {
    $target_file = "./uploadFiles/". $_FILES['upload']['name'][$i];
    $tmpFilePath = $_FILES['upload']['tmp_name'][$i];
		$random='';
		if(file_exists( $target_file)){
    $random=rand(0,100000000);
		} 
    if ($tmpFilePath != ""){
      $newFilePath = "./uploadFiles/" . $_FILES['upload']['name'][$i];
      if(move_uploaded_file($tmpFilePath, $newFilePath)) {
        echo "File uploaded";
				$rename= preg_replace('/\\.[^.\\s]{3,4}$/', '',$_FILES['upload']['name'][$i]);
				rename( $target_file,"./uploadFiles/{$rename}{$random}.jpg");
      }
      else{
        echo "Some thing Wrong";
      }
  	}

  }
?>