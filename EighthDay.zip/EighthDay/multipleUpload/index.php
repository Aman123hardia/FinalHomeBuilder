<!DOCTYPE html>
<html lang="en">
<head>
  <title>Uploads Files</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">

</head>
<body>
 <div class="container">
   <h1>Multiple Files Upload </h1>
		
	  <!-- Form to take multiple files -->
		<form enctype="multipart/form-data" action="upload.php" method="POST">
			<input type="file"  class="form-control"  name="upload[]" multiple="multiple"></input>
			<br/>
			<button type="submit" class="btn btn-success" value="Upload">Upload</button>
		</form>

	</div>

</body>
</html>