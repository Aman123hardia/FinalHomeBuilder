<?php
setcookie("TestCookie","SomeValue");
header("X-Sample-Test: foo");
header("Content-type: text/plain");
?>

<html>
<body>

<?php
var_dump(headers_list());
?>

</body>
</html>