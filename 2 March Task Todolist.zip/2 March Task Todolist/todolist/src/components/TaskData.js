export default [
    {
        name:"Task 1",
        level:1,
        status:"Active",
        Date:"2/03/2023"
    },
    {

        name:"Task 2",
        level:3,
        status:"Deactive",
        Date:"1/02/2023"
    },
    { 
    
        name:"Task 3",
        level:2,
        status:"Active",
        Date:"4/02/2023"
    },
    {  
        name:"Task 4",
        level:2,
        status:"Active",
        Date:"3/03/2023"
    },
    {    
     
        name:"Task 5",
        level:3,
        status:"Active",
        Date:"3/03/2023"
    }
]
