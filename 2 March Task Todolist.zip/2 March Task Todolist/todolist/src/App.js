import TaskData from './components/TaskData';
import { useState } from 'react';
import './App.css';


function App() {
  const [todoData,setTodoData]=useState(TaskData);
  const level=[{level:"low",priority:1},{level:"Medium",priority:2},{level:"High",priority:3}];

  const AddTask=()=>{
    
  }
 
return (
      <div class="container">
        <h1><div className='font-weight-bold text-center'>TodoList</div></h1>
     <div className="col-md-4 ml-3 "  style={{marginTop:'2vh'}}>
      <input type="text" class="form-control" placeholder='Enter Task Name'/>
     </div>
     <div className="col-md-4 ml-3"  style={{marginTop:'2vh'}}>
      <select className="form-control" >
        {level.map(data=><option>{data.level}</option>)}
    </select> 
    </div>
       <div className="col-md-4" style={{marginTop:'2vh'}}>
       <button type="button" class="btn btn-success" onClick={{AddTask}}>Add Task</button>
    </div>
    
   <table class="table table-striped pd-'40px'">
    <thead>
      <tr>
        <th>Task</th>
        <th>Level</th>
        <th>Status</th>
        <th>Date</th>
        <th>Edit</th>
        <th>Remove</th>
      </tr>
    </thead>
    <tbody>
    {todoData.filter((name=>name.status=="Active")).sort((a,b)=>a.level-b.level).map((data,index)=>{
        const myobj={background:data.level===1 ? "lightYellow" : data.level===2 ? "lightgreen" : "orange"};
         return  <tr style={myobj}>
          <td>{data.name}</td>
          <td>{level.map(res=>res.priority==data.level?res.level:"")}</td>
          <td>{data.status}</td>
          <td>{data.Date}</td>
          <td><button type="button" class="btn btn-info" >Edit Task</button></td>
          <td><button type="button" class="btn btn-danger" >Delete  Task</button></td>

        </tr>
        })}

    </tbody>
  </table>
    </div>
  );
}

export default App;
