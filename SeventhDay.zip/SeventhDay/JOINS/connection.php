<?php
 $localhost="127.0.0.1";
 $username= "root";
 $conn = new mysqli($localhost, $username);
	if ($conn-> connect_error) {
		die(" Connection failed: " . $conn->connect_error);
	}
	else {
		echo "Connected successfully ";
		/*Create Databases */
    $sql = "CREATE DATABASE `AccountManage`";
		if ($conn->query($sql) === TRUE) {
			echo "Database created successfully <br>";
		} 
		else {
			echo "Error creating database: " . $conn->error;
		}
		/*End Databases */
	
  if ($conn-> query("use AccountManage") === TRUE) 
		{
		/*Create Tables */
			$tableField = array("Employees (EmpId INTEGER primary key AUTO_INCREMENT, Name varchar(50) NOT NULL,Contact int(10) NOT NULL ,Address varchar(80),JoinDate datetime default now())",
			"EmployeeAttendence (AttId INTEGER primary key AUTO_INCREMENT,Month varchar(30),No_of_Days_present int(3), No_of_Days_absent int(3),Total_Days int(3))",
			"EmployeePayroll (PayId INTEGER primary key AUTO_INCREMENT,Salary int(5) Default 7000)"
			);

			foreach($tableField as $table){
			
				if ($conn-> query("Create Table ".$table) === TRUE) {
						echo "Table create Successfully";
					$conn-> query("ALTER TABLE Employees AUTO_INCREMENT=100");
					}
				else {
				 echo "Something wrong". $conn->error;;
				}
			}
    /*End Tables */

		/*Insert Data into Tables Employees */
		$Employeesdata=["('Aman','122154654','Indore Badganaga')","('Nitesh','44554466','Indore Badganaga')",
		"('Shubham','745646645','Indore Badganaga')","('Divyanshi','45456789','DoreGagh Badganaga')",
		"('Vinay','574456789','Paravati Khande Badganaga')","('Shubahsh','454456789','Aradhana Nagar Badganaga')",
		"('Ritik','45456789','Chor Bazar Badganaga')","('Mohit','45678789','Marimata')",
		"('Nidha','457846789','Indore Badganaga')","('Mayank','457586789','Indore Badganaga')",
		"('Kahan','455546789','Indore Badganaga')",
	  ];

		foreach($Employeesdata as $rec){
			$sql= "INSERT INTO `Employees`( `Name`, `Contact`, `Address`) VALUES $rec";
			echo $sql;
			if ($conn->query($sql) === TRUE) {
				echo "".$sql."Insert Data successfully <br>";
			} else {
				echo "Error Insert Succesfuly: " . $conn->error;
			}
		}
  	/*End Insert Data into Tables Employees */

		/*Insert Data into Tables EmployeeAttendence */
		$Employeesdata=["('January','20','11','30')","('January','25','5','30')","('January','26','4','30')",
		"('January','27','3','30')","('January','28','2','30')","('January','29','1','30')","('January','30','0','30')",
		"('January','30','0','30')","('January','30','0','30')","('January','28','2','30')","('January','27','3','30')",
		];
		
		foreach($Employeesdata as $rec){
			$sql= "INSERT INTO `EmployeeAttendence`(`Month`,`No_of_Days_present`,`No_of_Days_absent`,`Total_Days`) VALUES $rec";
			echo $sql;
			if ($conn->query($sql) === TRUE) {
				echo "".$sql."Insert Data successfully <br>";
			} else {
				echo "Error Insert Succesfuly: " . $conn->error;
			}
		}

		/*End Insert Data into Tables EmployeeAttendence */


		/*Insert Data into Tables EmployeePayroll */
		$Employeesdata=["(30000)","(12000)","(15000)","(18000)","(60000)","(90000)","(10000)","(80000)","(8000)","(21200)","(36000)"];
		
		foreach($Employeesdata as $rec){
			$sql= "INSERT INTO `EmployeePayroll`( `Salary`) VALUES $rec";
			echo $sql;
			if ($conn->query($sql) === TRUE) {
				echo "".$sql."Insert Data successfully <br>";
			} else {
				echo "Error Insert Succesfuly: " . $conn->error;
			}
		}
	}
}
 /* End Insert Data into Tables EmployeePayroll */
		
?>
	

	

		

