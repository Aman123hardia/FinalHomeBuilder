<?php
  require_once('createTable.php');
	
	// Update Table 
	function updateData($conn){
		$sql = "UPDATE `Employees` SET Name='Rahul' WHERE EmpId=101";
        if ($conn-> query($sql) === TRUE) {
			echo "<br> UseDatabase Connected Successfully";
		}
		else{
			echo "<br>Error Something Wrong"; 
		}
 }
 
 updateData($conn);

	  

?>
