<?php
  require_once('createTable.php');
	
	// Update Table 
	function deleteData($conn){
		$sql = "DELETE FROM `Employees` WHERE EmpID=111";
        if ($conn-> query($sql) === TRUE) {
			echo "<br> UseDatabase Connected Successfully";
		}
		else{
			echo "<br>Error Something Wrong"; 
		}
 }
 
 deleteData($conn);
?>