<?php
 $localhost="127.0.0.1";
 $username= "root";
 $conn = new mysqli($localhost, $username);
  
	//create connection
	function createConnection()
	{
		if ($conn-> connect_error) {
			die(" Connection failed: " . $conn->connect_error);
		}
		else {
			echo "Connected successfully ";
		}
  }


	  //create Database 
	function createDatabase($conn,$database)
	{
		$sql = "CREATE DATABASE ".$database;
		if ($conn->query($sql) === TRUE) {
			echo "".$database."Database created successfully <br>";
		} else {
			echo "Error creating database: " . $conn->error;
		}
	}



createConnection();
// createDatabase($conn,(string)readline("Enter Database Name :- "));

?>
