<?php
  require_once('connection.php');
	
	//connect to Database;
	function useDatabase($conn){
		$sql = "use ThroughOut";
    if ($conn-> query($sql) === TRUE) {
			echo "<br> UseDatabase Connected Successfully";
		}
		else{
			echo "<br>Error Something Wrong"; 
		}
 }
 
 //create table successfully;
 function createTable($conn){
	$emp= "Create Table Employees (EmpId INTEGER primary key AUTO_INCREMENT, Name varchar(50) NOT NULL, Email varchar(80) NOT NULL,Contact int(10) NOT NULL ,Address varchar(80),Salary int(10) NOT NULL,JoinDate datetime default now())";
	if ($conn-> query($emp) === TRUE) {
			echo "Table create Successfully";
			$conn-> query("ALTER TABLE Employees AUTO_INCREMENT=100");
		}
		else{
			echo "Something wrong";
		}
	}

	useDatabase($conn);
    // createTable($conn);
	  

?>
