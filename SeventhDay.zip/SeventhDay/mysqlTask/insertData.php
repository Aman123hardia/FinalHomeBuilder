<?php

  require_once('createTable.php');

	function insertData($conn){
		$data=["('Aman','Aman@gmail.com','23546354','Indore Badganaga',100000)",
						"('Nitesh','Nitesh@gmail.com','141631613','Indore Badganaga',103000)",
						"('Shubham','Shubham@gmail.com','466451','Indore Badganaga',13000)",
						"('Divyanshi','Divyanshi@gmail.com','123456789','DoreGagh Badganaga',12000)",
						"('Vinay','Vinay@gmail.com','123456789','Paravati Khande Badganaga',32000)",
						"('Shubahsh','Shubahsh@gmail.com','123456789','Aradhana Nagar Badganaga',30000)",
						"('Ritik','Ritik@gmail.com','123456789','Chor Bazar Badganaga',30000)",
						"('Mohit','Mohit@gmail.com','123456789','Marimata',20000)",
						"('Nidha','Nidha@gmail.com','123456789','Indore Badganaga',32000)",
						"('Mayank','Mayank@gmail.com','123456789','Indore Badganaga',30000)",
						"('Kahan','Kahan@gmail.com','123456789','Indore Badganaga',50000)",
	
	];
	foreach($data as $rec){
  $sql= "INSERT INTO `Employees`( `Name`, `Email`, `Contact`, `Address`, `Salary`) VALUES $rec";
	echo $sql;
	if ($conn->query($sql) === TRUE) {
		echo "".$sql."Insert Data successfully <br>";
	} else {
		echo "Error Insert Succesfuly: " . $conn->error;
	}
 }
 
}
 insertData($conn);


?> 



















































 