<?php
  require_once('connection.php');
	
	//Drop Table ;
	function dropTable($conn){
		$sql = "Drop Table Employees";
    if ($conn-> query($sql) === TRUE) {
			echo "<br> UseDatabase Connected Successfully";
		}
		else{
			echo "<br>Error Something Wrong"; 
		}
 }
 
 	//Drop Database;
 function dropDatabase($conn){
		$sql = "Drop Table Employees";
		if ($conn-> query($sql) === TRUE) {
			echo "<br> UseDatabase Connected Successfully";
		}
		else{
			echo "<br>Error Something Wrong"; 
		}
	}

dropTable($conn);
dropDatabase($conn);
	  

?>
