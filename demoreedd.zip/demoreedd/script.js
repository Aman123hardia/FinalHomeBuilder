 $("#step1").show()
let step=2;

function next(){
    let temp=step;
    step="#step"+step
    $(step).show()
    step=temp+1;
 }
function back(){
    step="#step"+step
    $(step).show()
    previous-=1;
}