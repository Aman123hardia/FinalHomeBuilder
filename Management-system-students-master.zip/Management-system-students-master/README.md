# Management-system-students

<br>
<br>
It allows students to see their records by entering the standard and the roll.no.
<br>
As per the admin privilages, 
<br>
Id: Admin
Password: Admin
<br>
In admin dashboard, you can
<br>
1. Insert student records,
<br>
2. Update student records,
<br>
3. Deleting student records.
<br>
<hr>
<b> I created MySql database in PHP My Admin and hence if you wish to use the code, create a database in my case,
  <br>
  database name : sms
  <br>
  Create two table one for student and one for admin. In my case the table names are,
  <br>
  Admin,Student
  <br>
  </b>
Also, I have used WAMP server and for using PHP My Admin, my username was <b>root</b> and password was<b>""</b>.
In case you have a different one, edit it in the <b><i>dbcon.php</i></b>file.
<hr>
