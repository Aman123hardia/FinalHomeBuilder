<?php
require('databaseCon.php');



if ($conn-> query("use EMS") === TRUE) 
{
  
    $sql = "SELECT `First_Name` FROM `Admin`";
    echo "hello".$sql;
    if ($conn-> query("select * from  Admin") === TRUE) {
      echo "meow";
echo $result->num_rows;
if ($result->num_rows > 0) {
  while($row = $result->fetch_assoc()) {
    echo "Salary: " . $row["First_Name`"];
  }
} else {
  echo "0 results";
}
}
}
?> 