<?php
require('databaseCon.php');
$email=$_POST["email"];
$pass=$_POST["password"];

if ($conn-> query("use EMS") === TRUE) 
{
  
  $result=mysqli_query($conn,"select `Password` from admin where `Email`='$email'");
  $row=mysqli_fetch_array($result);
  $decrypt =$row['Password'];

  $verify=password_verify($pass , $decrypt );

  if($verify){
    echo "successfully login";
    header("Location:http://localhost/PHP/WebsiteDesign/adHome.php"); 
            echo '<script type="text/javascript">
            window.onload = function () { alert("Successfuly Login"); } 
     </script>';
  }
  else{
  echo "Mismatch Password";
  echo $Hello;
  header("Location:http://localhost/PHP/WebsiteDesign/signIn.php");}    
   $conn->close();
}
?> 