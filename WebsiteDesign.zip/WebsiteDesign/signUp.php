<!DOCTYPE html>
<html lang="en">
<head>
  <title>Shopping</title> 
	<link rel="icon" type="image/png" href="images/shopping-cart.png"/>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link href='style.css'  rel='stylesheet'>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.3/jquery.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"></script>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
</head>

<body>
  <!-- container start -->
  <div class='container mt-1 bg-light border border-grey '>	
    <!-- Header start -->
    <div class='container-fluid bg-secondary '  > 
    <nav class="navbar navbar-expand-lg navbar-light ">
            <img src="images/icon1.png" width="50" height="50" alt="" class="">
            <div class='text-center text-white p-3 ' style='width:100%'><h3>Employee Management System</h3></div>
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNavDropdown" aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
</nav> 
            </button>
    
    </div>
    <!-- Header End -->
   
    <div class="row">
      <!-- Right Side Image Start -->
      <div class="col-lg-6 mt-1 mb-3">
        <img src='images/sign.png' class="img-fluid " style='height:100%'/>
      </div>
      <!-- Right Side Image End -->
         
      <!-- Sign Up Form Start-->
      <div class="col-lg-6 mt-1 pt-1 bg-light mb-1 p-3">
        
       <form action="/action_page.php">
       <h2 class='text-center text-dark p-1 text-center' >SignUp Form</h2>
          <div class="mb-2 mt-2 ">
              <label for="fname">First Name</label>
              <input type="text" class="form-control" id="fname" placeholder="Enter First Name" name="fname">
          </div>
              
          <div class="mb-3 ">
            <label for="fname">Last Name</label>
            <input type="text" class="form-control" id="lname" placeholder="Enter Last Name" name="lname">
          </div>

          <div class="mb-3 mt-3 ">
            <label for="email">Email:</label>
            <input type="email" class="form-control" id="email" placeholder="Enter Your Email" name="email">
          </div>
            
          <div class="mb-3 mt-3 ">
            <label for="email">Password:</label>
            <div class="input-group mb-3">
                <input name="password" type="password" value="" class="input form-control" id="password" placeholder="password" required="true" aria-label="password" aria-describedby="basic-addon1" />
                  <span class="input-group-text p-3" onclick="showPass();">
                    <i class="fa fa-eye" id="show_eye" aria-hidden="true"></i>
                    <i class="fa fa-eye-slash" id="hide_eye" aria-hidden="true"  style='display:none' ></i>
                  </span>
            </div>
          </div>
            
          <div class="form-check mb-3">
            <span class="w-30 bg-blue" style='margin-left:28%'>
            <a href="http://localhost/phplearning/EleventhDay/PROJECT/PROJECT/forget.php" style='text-decoration:none' >Forget Password</a>
            </span>
            <span class="w-30" style='margin-left:5%'>
               <a href="http://localhost/phplearning/EleventhDay/PROJECT/PROJECT/loginUp.php" style='text-decoration:none' >SignIn</a>
            </span>
          </div>
          
          
          <div class="text-center mt-2">
          <button type="button" class="btn btn-secondary btn-lg btn-block w-50">Submit</button>
          </div>
        </form>
          <!-- SignUp Form End -->
    </div>
    <!-- row End-->
  </div>
 <script>
  function showPass(){

  let x = document.getElementById("password");
  let y = document.getElementById("show_eye")
  let z = document.getElementById("hide_eye");
  if (x.type === "password") {
    x.type = "text";
    y.style.display='none';
    z.style.display='block';
  } else {
    x.type = "password";
    y.style.display='block';
    z.style.display='none';
    
  }

}
 </script>
</body>

