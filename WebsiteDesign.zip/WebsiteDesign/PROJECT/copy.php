<!DOCTYPE html>
<html lang="en">
<head>
  <title>Shopping</title> 
	<link rel="icon" type="image/png" href="images/shopping-cart.png"/>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link href="style.css" rel="stylesheet" />
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.3/jquery.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"></script>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
</head>

<body>
  <!-- container start -->
  <div class='container mt-3'>	
  <!DOCTYPE html>
<html>
     
<head>
    <title>
        How to call PHP function
        on the click of a Button ?
    </title>
</head>
 
<body style="text-align:center;">
     
    <h1 style="color:green;">
        GeeksforGeeks
    </h1>
     
    <h4>
        How to call PHP function
        on the click of a Button ?
    </h4>
     
    <?php
        if(array_key_exists('button1', $_POST)) {
            button1();
        }
        else if(array_key_exists('button2', $_POST)) {
            button2();
        }
        function button1() {
            echo "This is Button1 that is selected";
        }
        function button2() {
            echo "This is Button2 that is selected";
        }
    ?>
  <form  method="post">
       
         
   

                <div class="input-group mb-3">
              <input name="password" type="password" value="" class="input form-control" id="password" placeholder="password" required="true" aria-label="password" aria-describedby="basic-addon1" />
              <div class="input-group-append">
                <span class="input-group-text p-3 button" onclick="showPass();">
                <input type="submit" name="button1"
                class="button" value="Button1" />
                <input type="submit" name="button2"
                class="button" value="Button2" />
                  <i class="fa fa-eye button" value="Button2"id="show_eye" aria-hidden="true"></i>
                  <i class="fa fa-eye-slash button" value="Button2" id="hide_eye" aria-hidden="true"  style='display:none' ></i>
                </span>
              </div>
            </div>
    </form>
</body>
 
</html>
 
