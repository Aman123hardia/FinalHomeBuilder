<div class="mb-2 mt-2 ">
  <label for="fname">First Name</label>
  <input type="text" class="form-control" id="fname" placeholder="Enter First Name" name="fname" required>
</div>

<div class="mb-3 ">
  <label for="fname">Last Name</label>
  <input type="text" class="form-control" id="lname" placeholder="Enter Last Name" name="lname">
</div>

<div class="mb-3 mt-3 ">
  <label for="email">Email:</label>
  <input type="email" class="form-control" id="email" placeholder="Enter Your Email" name="email">
</div>

<div class="mb-3 mt-3 ">
  <label for="email">Password:</label>
  <div class="input-group mb-3">
    <input name="password" type="password" value="" class="input form-control" id="password" placeholder="password"
      required="true" aria-label="password" aria-describedby="basic-addon1" />
    <span class="input-group-text p-3" onclick="showPass();">
      <i class="fa fa-eye" id="show_eye" aria-hidden="true"></i>
      <i class="fa fa-eye-slash" id="hide_eye" aria-hidden="true" style='display:none'></i>
    </span>
  </div>
</div>