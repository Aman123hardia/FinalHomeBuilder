<?php
  require_once('../connection/databaseCon.php');
  $email=$_POST["email"];
  $pass=$_POST["password"];
  echo $email,$pass;
  if ($conn-> query("use ems") === TRUE) 
  {
    $result=mysqli_query($conn,"select * from `Admin` where `Email`='$email'");  //check email in database
    $row=mysqli_fetch_array($result); 
    $decrypt =$row['Password'];
    $verify=password_verify($pass , $decrypt);

    if($verify){
    
      session_start();
      $_SESSION['AdminId']=$row['AdminId'];
      $_SESSION['Name']=$row['First_Name'];
      ?>
      <script>
        alert('SignIn Successfully');
        window.open('../admin/adHome.php','_self');
      </script>
      <?php
    }
    else{
    echo "Mismatch Password";
    echo $Hello;
    header("Location:signIn.php");
  }    
    $conn->close();
  }
?> 