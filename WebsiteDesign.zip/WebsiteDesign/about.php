
      <div class="row align-items-center">
        <div class="col-lg-6">
          <h1 class="display-4">About us page</h1>
          <p class="lead text-muted ">Create a minimal about us page using Bootstrap 4.</p>
          <p class="lead text-muted">Snippet by <a href="https://bootstrapious.com/snippets" class="text-muted"> 
                      <u>Bootstrapious</u></a>
          </p>
        </div>
        <div class="col-lg-6 d-none d-lg-block"><img src="https://bootstrapious.com/i/snippets/sn-about/illus.png" alt="" class="img-fluid"></div>
      </div>
