<?php
require_once('databaseCon.php');
    $name=$_POST["fname"];
    $lname=$_POST["lname"];
    $email=$_POST["email"];
    $pass=$_POST["password"];
    echo  $name,$lname,$email, $pass;
    $encryptPass = password_hash($pass, PASSWORD_DEFAULT);
    if ($conn-> query("use EMS") === TRUE) 
    {
        $val="('$name','$lname','$email','$encryptPass')";
        $sql= "INSERT INTO `Admin`( `First_Name`, `Last_Name`, `Email`,`Password`) VALUES $val";
        if ($conn->query($sql) === TRUE) {

            header("Location:http://localhost/PHP/WebsiteDesign/adHome.php"); 
            echo '<script type="text/javascript">
            window.onload = function () { alert("Successfuly Login"); } 
     </script>';
 
        } else {
            echo $Hello;
            header("Location:http://localhost/PHP/WebsiteDesign/signUp.php"); 
        }
        $conn->close();
    }
?>  
