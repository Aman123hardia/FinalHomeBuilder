
 
<?php 
// session check and Database Connection
session_start();
if(isset($_SESSION['AdminId']))
{
  require_once('../website/title.php'); 
  require_once('../connection/databaseCon.php');
}
else{
    header('location: ../website/signIn.php');
}
?>

<body>

<!-- Show List of Employees -->
<div class="container-fluid">
<?php require_once('sideNav.php');?>
<div class="col py-3 px-5 border border-light  bg-light">
  <h3 class="text-center mb-5 pb-2 pt-2" style="background-color:rgb(228, 221, 212)">Employee List
  <spna>   <img src="../images/elist.png" width="50" height="50" alt="" class="pl-3"></span></h3>
<table class="table bg-light text-center">
  <thead class="thead-dark ">
    <tr>
     <th scope="col">S.No</th>
      <th scope="col">First</th>
      <th scope="col">Last</th>
      <th scope="col">Email</th>
      <th scope="col">AdminId</th>
      <th scope="col">JoinDate</th>
      <th scope="col">Actions</th>
    </tr>
  </thead>
  <tbody>
<?php
  if ($conn-> query("use ems") === TRUE) 
   $result=mysqli_query($conn,"select * from `Admin`");
     $sn=1;
     if(mysqli_num_rows($result)<1){
      echo "<tr><td colspan='10' class='text-center bg-secondary'>No Records Found</td></tr>";
     }
      while($row=mysqli_fetch_array($result)){
        ?>
      <tr>
        <td><?php echo $sn ;?></td>
                <td><?php echo $row['First_Name']; ?></td>
                <td><?php echo $row['Last_Name'];  ?></td>
                <td><?php echo $row['Email']; ?></td>
                <td><?php echo $row['AdminId']; ?></td>
      
                <td><?php echo $row['JoinDate'];  $sn++; ?></td>
                <th scope="col"><button class='btn btn-success '><a style='text-decoration:none' class='link-light' href="updateform.php?EmId=<?php echo $row['AdminId']; ?>">Update</a></button>
                <button class='btn btn-danger' ><a style='text-decoration:none' class='link-dark' href="deleteEmp.php?EmId=<?php echo $row['AdminId']; ?>">Delete</a></button></th>
      <?php
      }
?> 
</tbody>
</table>
</div>
</body>