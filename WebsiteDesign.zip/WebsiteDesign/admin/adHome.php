
 
<?php 
session_start();

if(isset($_SESSION['AdminId']))
{
    echo "";
}
else{
    header('location: ../website/signIn.php');
}

require_once('../website/title.php'); 
require_once('../connection/databaseCon.php')


?>
<body>
<div class="container-fluid">
  <?php require_once('sideNav.php');?>
        <div class="col py-3 px-5 border border-light  bg-light">
<table class="table bg-light">
  <thead class="thead-dark ">
    <tr>
     <th scope="col">S.No</th>
      <th scope="col">First</th>
      <th scope="col">Last</th>
      <th scope="col">Email</th>
      <th scope="col">AdminId</th>
      <th scope="col">JoinDate</th>
      <th scope="col">Actions</th>

    </tr>
  </thead>
  <tbody>
  <?php
  if ($conn-> query("use ems") === TRUE) 
   $result=mysqli_query($conn,"select * from `Admin`");
     
      $sn=1;
      while($row=mysqli_fetch_array($result)){
        ?>
      <tr>
        <td><?php echo $sn ;?></td>
                <td><?php echo $row['First_Name']; ?></td>
                <td><?php echo $row['Last_Name'];  ?></td>
                <td><?php echo $row['Email']; ?></td>
                <td><?php echo $row['AdminId']; ?></td>
      
                <td><?php echo $row['JoinDate'];  $sn++; ?></td>
                <th scope="col"><button class='btn btn-success'>Edit</button><button class='btn btn-danger mr-2'>Delete</button></th>
      <?php
      }
    ?> 
  </tbody>
</table>
