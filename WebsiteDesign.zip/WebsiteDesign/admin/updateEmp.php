<?php 
session_start();
if(isset($_SESSION['AdminId']))
{
  require_once('../connection/databaseCon.php');
  if ($conn-> query("use ems") === TRUE) 
	{
		$id=$_POST["EmId"];
		$fname=$_POST["fname"];
		$lname=$_POST["lname"];
		$email=$_POST["email"];
		$pass=$_POST["password"];

		echo $id;
		$qry = "UPDATE `Admin` SET `First_Name` = '$fname', `Last_Name` = '$lname', `Email` = '$email', `Password` = '$pass' WHERE `AdminId` = $id;";
		$result = mysqli_query($conn,$qry);

			if($result == true){
				?>
				<script>
					alert('Data Updated Successfully');
					window.open('adHome.php','_self');
				</script>
				<?php
			}
	}
}
else{
    header('location: ../website/signIn.php');
}

?>
