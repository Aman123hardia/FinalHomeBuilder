
<?php 
	session_start();
	if(isset($_SESSION['AdminId']))
	{
		require_once('../website/title.php'); 
		require_once('sideNav.php');
	}
	else{
			header('location: ../website/signIn.php');
	}

?>

<!--Container-->
<div class="col py-3 px-5 border border-light  bg-light">
	<!-- Header -->
	<h3 class="text-center mb-5 pb-2 pt-2" style="background-color:rgb(228, 221, 212)">Add Employee
		<spna> <img src="../images/addEm.png" width="50" height="50" alt="" class="pl-3"></span>
	</h3>

	<!-- Add Employee Form -->
	<form action="../website/formData.php" method="post">
	<?php require_once('../website/formSignUp.php'); ?>
	<!-- show hide password function  -->
	<script src='../website/pass.js'></script>
	<div class="text-center mt-5">
			<button type="submit" class="btn btn-success text-white btn-lg btn-block w-50">Add</button>
		</div>
	</form>
</div>

