<?php 
	session_start();
	if(isset($_SESSION['AdminId']))
	{
		require_once('../website/title.php'); 
		require_once('sideNav.php');
		require_once('../connection/databaseCon.php');
		$EmId = $_GET['EmId'];
		if ($conn-> query("use ems") === TRUE) 
		$qur = "SELECT * FROM `Admin` WHERE `AdminId` = '$EmId'";
		$run = mysqli_query($conn,$qur);
		$record=mysqli_fetch_assoc($run);
	}
	else{
		header('location: ../website/signIn.php');
	}
?>

<div class="col py-3 px-5 border border-light  bg-light">
	<!--  UPDATE HEADER -->
	<h3 class="text-center mb-5 pb-2 pt-2" style="background-color:rgb(228, 221, 212)">Update Employee
		<spna> <img src="../images/addEm.png" width="50" height="50" alt="" class="pl-3"></span>

	</h3>

   <!-- update Form -->
	<form action="updateEmp.php" method="post">
		<div class="mb-3 mt-3 ">
			<label for="EmId">EmpId:</label>
			<input type="hidden" class="form-control" id="EmId" name="EmId" value="<?php echo $_REQUEST['EmId']; ?>">
		</div>

		<div class="mb-2 mt-2 ">
			<label for="fname">First Name</label>
			<input type="text" class="form-control" id="fname" value=<?php echo $record['First_Name'] ?> name="fname"
			required>
		</div>

		<div class="mb-3 ">
			<label for="fname">Last Name</label>
			<input type="text" class="form-control" id="lname" value=<?php echo $record['Last_Name'] ?> name="lname">
		</div>

		<div class="mb-3 mt-3 ">
			<label for="email">Email:</label>
			<input type="email" class="form-control" id="email" value=<?php echo $record['Email'] ?> name="email">
		</div>

		<div class="mb-3 mt-3 ">
			<label for="email">Password:</label>
			<div class="input-group mb-3">
				<input name="password" type="password" value="" class="input form-control" id="password" value=<?php echo
					$record['Password'] ?> required="true" aria-label="password" aria-describedby="basic-addon1" />
				<span class="input-group-text p-3" onclick="showPass();">
					<i class="fa fa-eye" id="show_eye" aria-hidden="true"></i>
					<i class="fa fa-eye-slash" id="hide_eye" aria-hidden="true" style='display:none'></i>
				</span>
			</div>
		</div>
		<!-- show hide password function  -->
		<script src='../website/pass.js'></script>
		
		<div class="text-center mt-5">
			<button type="submit" class="btn btn-success text-white btn-lg btn-block w-50">Update</button>
		</div>
	</form>
</div>