 
<?php 
session_start();
if(isset($_SESSION['AdminId']))
{
    echo "";
}
else{
    header('location: ../website/signIn.php');
}
?>
