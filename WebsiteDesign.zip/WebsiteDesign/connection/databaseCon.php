<?php
 $localhost="127.0.0.1";
 $username= "root";
 $conn = new mysqli($localhost, $username);

	if ($conn-> connect_error) {
		die(" Connection failed: " . $conn->connect_error);
	}
	else {
		// echo "Connected successfully ";
		/*Create Databases */
    $sql = "CREATE DATABASE IF NOT EXISTS  `ems`";
		if ($conn->query($sql) === TRUE) {
			// echo "Database created successfully <br>";
		} 
		else {
			// echo "Error creating database: " . $conn->error;
		}
		/*End Databases */
	}

?>