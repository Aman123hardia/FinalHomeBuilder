<?"ALTER TABLE EmployeePayroll
ADD FOREIGN KEY (EmpId) REFERENCES Employees(EmpId);"
?> 