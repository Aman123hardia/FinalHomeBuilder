<?php
		$Employeesdata=["('Aman','122154654','Indore Badganaga')","('Nitesh','44554466','Indore Badganaga')",
		"('Shubham','745646645','Indore Badganaga')","('Divyanshi','45456789','DoreGagh Badganaga')",
		"('Vinay','574456789','Paravati Khande Badganaga')","('Shubahsh','454456789','Aradhana Nagar Badganaga')",
		"('Ritik','45456789','Chor Bazar Badganaga')","('Mohit','45678789','Marimata')",
		"('Nidha','457846789','Indore Badganaga')","('Mayank','457586789','Indore Badganaga')",
		"('Kahan','455546789','Indore Badganaga')",
	  ];

?>