<?php

/*Inner Join*/
$inner="SELECT Employees.Name, EmployeeAttendence.No_of_Days_present,EmployeeAttendence.No_of_Days_absent
FROM EmployeeAttendence
INNER JOIN Employees ON Employees.EmpId=EmployeeAttendence.EmpId";


$inner1= "SELECT Employees.Name,
EmployeeAttendence.No_of_Days_present,
EmployeePayroll.Salary
  FROM Employees
  INNER JOIN EmployeeAttendence
  ON Employees.EmpId = EmployeeAttendence.EmpId
  INNER JOIN EmployeePayroll
  ON EmployeeAttendence.EmpId = EmployeePayroll.EmpId";
  /*End Inner Join*/


  /*Left Joins*/
$left= "SELECT Employees.Name, EmployeeAttendence.No_of_Days_present
FROM Employees
LEFT JOIN EmployeeAttendence ON Employees.EmpId = EmployeeAttendence.EmpId
ORDER BY Employees.Name";

$left1= "SELECT e.Name, e.Address, ea.No_of_Days_present, ep.Salary
FROM Employees e
LEFT JOIN EmployeeAttendence ea
ON e.EmpId = ea.EmpId
LEFT JOIN EmployeePayroll ep
ON ea.EmpId = ep.EmpId";
  /*End Left Joins*/

/* Right Joins*/
$right= "SELECT Employees.Name, EmployeeAttendence.No_of_Days_present
FROM EmployeeAttendence
Right JOIN Employees ON EmployeeAttendence.EmpId = Employees.EmpId
ORDER BY Employees.Name;";

$right1="SELECT e.Name, e.Address, ea.No_of_Days_present, ep.Salary
FROM EmployeeAttendence ea
RIGHT JOIN Employees e
ON ea.EmpId = e.EmpId
RIGHT JOIN EmployeePayroll ep
ON e.EmpId = ep.EmpId;";

/*End Right Joins*/


/* Cross Join*/
$cross="SELECT Employees.EmpId,EmployeeAttendence.EmpId
FROM Employees
CROSS JOIN EmployeeAttendence";

$cross="SELECT Employees.EmpId,EmployeeAttendence.EmpId,EmployeePayroll.Salary
FROM Employees
CROSS JOIN EmployeeAttendence CROSS JOIN EmployeePayroll";
?>
