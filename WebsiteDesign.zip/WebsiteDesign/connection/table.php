<?php
require_once('databaseCon.php');
  if ($conn-> query("use ems") === TRUE) 
		{
		/*Create Tables */
			$tableField = array("Admin (AdminId INTEGER primary key NOT NULL AUTO_INCREMENT, First_Name varchar(50) NOT NULL,Last_Name varchar(50) NOT NULL,Email varchar(50) NOT NULL UNIQUE, Password varchar(300) NOT NULL,JoinDate datetime default now())",
			"Employees(EmpId INTEGER primary key   AUTO_INCREMENT, First_Name varchar(50) NOT NULL,Last_Name varchar(50) NOT NULL,Email varchar(50) NOT NULL UNIQUE, Password varchar(300) NOT NULL,JoinDate datetime default now())AUTO_INCREMENT = 1001",	
			"EmployeesDetails(DetId INTEGER  primary key AUTO_INCREMENT, First_Name varchar(50) NOT NULL,Last_Name varchar(50) NOT NULL,Email varchar(50) NOT NULL UNIQUE, Password varchar(300) NOT NULL,JoinDate datetime default now())AUTO_INCREMENT = 1",
			"EmployeeSalary(PayId INTEGER primary key  AUTO_INCREMENT,Salary int(5) Default 7000)AUTO_INCREMENT = 101",
			
		);

			foreach($tableField as $table){
			
				if ($conn-> query("Create Table IF NOT EXISTS ".$table) === TRUE) {
						// echo "Table create Successfully";
					}
				else {
				//  echo "Something wrong". $conn->error;
				}
			}
    /*End Tables */
	
		}
?>
