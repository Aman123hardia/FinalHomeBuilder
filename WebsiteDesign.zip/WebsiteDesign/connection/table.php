<?php
require_once('databaseCon.php');
  if ($conn-> query("use EMS") === TRUE) 
		{
		/*Create Tables */
			$tableField = array("Admin (adminId INTEGER primary key AUTO_INCREMENT, First_Name varchar(50) NOT NULL,Last_Name varchar(50) NOT NULL,Email varchar(50) NOT NULL UNIQUE, Password varchar(300) NOT NULL,JoinDate datetime default now())",
			);

			foreach($tableField as $table){
			
				if ($conn-> query("Create Table ".$table) === TRUE) {
						echo "Table create Successfully";
					$conn-> query("ALTER TABLE Employees AUTO_INCREMENT=100");
					}
				else {
				 echo "Something wrong". $conn->error;;
				}
			}
    /*End Tables */
	
		}
?>
