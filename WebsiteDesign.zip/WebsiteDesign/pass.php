<?php

// Plaintext password entered by the user
$plaintext_password = "12345678";

// The hashed password retrieved from database
$hash =
password_hash($plaintext_password,  PASSWORD_DEFAULT);

// Verify the hash against the password entered
$verify = password_verify($plaintext_password, $hash);

// Print the result depending if they match
if ($verify) {
	echo 'Password Verified!'.$verify;
} else {
	echo 'Incorrect Password!';
}
?>
