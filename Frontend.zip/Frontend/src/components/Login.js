import React from 'react'
import "./ModalCss/style.css";
const Login = () => {
     
    //MongoDB Atlas Login Process
     const login = async () =>{
     
        let response = await axios.post("http://localhost:3000/user/login",{email:loginEmail,password:loginPassword});
             if(response.request.status==200)
             {
              dispatch(setCustomer(response.data.user));
              dispatch(fetchPosts());
              firbaseLogin(response.data.user);
             }
            else 
            alert(response.data.message);
       }                                                                                                                                                                             
    
      //firbase Login Process
        const firbaseLogin = async (user)=>{
         alert('login');
          const email = signUpEmail;
          const password = signUpPassword;
          
          try {
          await signInWithEmailAndPassword(auth, email, password);
          navigate("/home",user);
          }catch(err){
          setErr1(true);
          }};

  return (
    <>
    <button type="button" className=" h1 btn btn-outline-success text-white text-bold" data-toggle="modal" data-target="#exampleModalCenter">
                Login
              </button>
    <div className="modal fade" id="exampleModalCenter" data-backdrop="false" tabIndex={-1} role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
      <div className="modal-dialog modal-dialog-centered" role="document">
        <div className="modal-content">
          <div className="modal-header">
            <button type="button" className="close d-flex align-items-center justify-content-center" data-dismiss="modal" aria-label="Close">
              <span aria-hidden="true" className="ion-ios-close" />
            </button>
          </div>
          <div className="modal-body p-4 py-5 p-md-5">
            <h3 className="text-center mb-3">Login Account</h3>
            <ul className="ftco-footer-social p-0 text-center">
              <li className="ftco-animate"><a href="#" data-toggle="tooltip" data-placement="top" title="Twitter"><span className="ion-logo-twitter" /></a></li>
              <li className="ftco-animate"><a href="#" data-toggle="tooltip" data-placement="top" title="Facebook"><span className="ion-logo-facebook" /></a></li>
              <li className="ftco-animate"><a href="#" data-toggle="tooltip" data-placement="top" title="Instagram"><span className="ion-logo-instagram" /></a></li>
            </ul>
            <form action="#" className="signup-form">
              <div className="form-group mb-2">
                <label htmlFor="email">Email Address</label>
                <input type="text" className="form-control"  onChange={(event)=>setLoginEmail(event.target.value)}/>
              </div>
              <div className="form-group mb-2">
                <label htmlFor="password">Password</label>
                <input type="password" className="form-control"  onChange={(event)=>setLoginPassword(event.target.value)}/>
              </div>
              <div className="form-group mb-2">
                <button  onClick={login}  className="form-control btn btn-primary rounded submit px-3">Sign In</button>
              </div>
              <div className="form-group d-md-flex">
                <div className="w-100 text-center">
                  <a href="#" className="forgot">I'm already a member</a>
                </div>
              </div>
            </form>
          </div>
        </div>
      </div>
    </div>
    </>
  )
};

export default Login