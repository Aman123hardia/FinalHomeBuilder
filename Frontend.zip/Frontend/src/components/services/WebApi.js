export default {
     LOAD_POSTS:"http://localhost:3000/post/list",
     ADD_POST:"http://localhost:3000/post/create",
     LOAD_SAVEPOST:"http://localhost:3000/savePost/list",
     ADD_SAVEPOST:"http://localhost:3000/savePost/post",
     ADD_LIKE:"http://localhost:3000/like/post"
}