import React from 'react';
import Nav from './Nav';
import Post from './Post';


const Home = () => {

  return (
    <div>
        <Nav></Nav>
       <Post></Post>
    </div>
  )
}

export default Home;
